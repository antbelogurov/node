module.exports = {
    host: "localhost", //127.0.0.1
    user: "root",
    database: "user",
    password: ""
};